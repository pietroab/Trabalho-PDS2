/**
 * @file Enumeração TipoCarta.
 */
#ifndef TIPOCARTA_H
#define TIPOCARTA_H

/**
 * @brief Tipos de Carta.
 */
enum class TipoCarta
{
    CARRO
};

#endif /* TIPOCARTA_H */

